function validateForm(form){
	var msg = "";
	
	var idVoo = form.getValue("idVoo");
	var numeroVoo = form.getValue("numeroVoo");


    if (form.getValue("idVoo") == "") {
        msg += i18n.translate("infIdVoo");
    }
    if (form.getValue("numeroVoo") == "") {
        msg += i18n.translate("infNumeroVoo");
    }
    if (form.getValue("localPartida") == "") {
        msg += i18n.translate("infLocalPartida");
    }
    if (form.getValue("localChegada") == "") {
        msg += i18n.translate("infLocalChegada");
    }
    if (form.getValue("horarioPartida") == "") {
        msg += i18n.translate("infHorarioPartida");
    }
    if (form.getValue("horarioChegada") == "") {
        msg += i18n.translate("infHorarioChegada");
    }
    if (form.getValue("portaoEmbarque") == "") {
        msg += i18n.translate("infPortao");
    }
    if (form.getValue("statusVoo") == "") {
        msg += i18n.translate("infStatus");
    }
    if (form.getValue("quantAssentos") == "") {
        msg += i18n.translate("infQuantAssentos");
    }
    if ( form.getValue("quantAssentos") <= 0) {
        msg += i18n.translate("infQuantAssentos2");
    }
    
    if (form.getValue("tipoDeVoo") == "") {
        msg += i18n.translate("infTipoVoo");
    }
  
    if (msg != "") {
        throw msg;
    }
    
    var dataset = DatasetFactory.getDataset("dsCadastrodeVoos", null, null, null);
    
    for (var i = 0; i < dataset.rowsCount; i++) {
        if (dataset.getValue(i, "idVoo") == idVoo ) {
            throw i18n.translate("idCadastrado1") +idVoo+ + " " + i18n.translate("idCadastrado2");
        }
    }
    
    for (var i = 0; i < dataset.rowsCount; i++) {
        if (dataset.getValue(i, "numeroVoo") == numeroVoo ) {
            throw i18n.translate("numeroCadastrado1") +numeroVoo + " " +i18n.translate("numeroCadastrado2");
        }
    }
}