function createDataset(fields, constraints, sortFields) {
    var dataset = DatasetBuilder.newDataset();

    dataset.addColumn("idVoo");
    dataset.addColumn("numeroVoo");
    dataset.addColumn("localChegada");
    dataset.addColumn("localPartida");
    dataset.addColumn("horarioPartida");
    dataset.addColumn("horarioChegada");
    dataset.addColumn("statusVoo");
    dataset.addColumn("quantAssentos");
    dataset.addColumn("tipoVoo");

    var dsFormulariosFinalizados = DatasetFactory.getDataset("dsFormulariosFinalizados", null, null, null);
    var dsVoos = DatasetFactory.getDataset("dsCadastrodeVoos", null, null, null);

    for (var i= 0; i < dsVoos.rowsCount; i++) {
        var idFormulario = dsVoos.getValue(i, "metadata#id");

        
        for (var j = 0; j < dsFormulariosFinalizados.rowsCount; j++) {
            var idFormularioFinalizado = dsFormulariosFinalizados.getValue(j, "cardDocumentId");

            if (idFormulario == idFormularioFinalizado) {
                var idVoo = dsVoos.getValue(i, "idVoo");
                var numeroVoo = dsVoos.getValue(i, "numeroVoo");
                var localPartida = dsVoos.getValue(i, "localPartida");
                var localChegada = dsVoos.getValue(i, "localChegada");
                var horarioPartida = dsVoos.getValue(i, "horarioPartida");
                var horarioChegada = dsVoos.getValue(i, "horarioChegada");
                var statusVoo = dsVoos.getValue(i, "statusVoo");
                var quantAssentos = dsVoos.getValue(i, "quantAssentos");
                var tipoVoo = dsVoos.getValue(i, "tipoDeVoo");

                dataset.addRow([
                    idVoo,
                    numeroVoo,
                    localChegada,
                    localPartida,
                    horarioPartida,
                    horarioChegada,
                    statusVoo,
                    quantAssentos,
                    tipoVoo
                ]);
                break; 
            }
        }
    }

    return dataset;
}
