function validateForm(form) {

    var msg = "";

    var idVoo = form.getValue("idVoo");
    var cpf = form.getValue("cpf");
    var assento = parseInt(form.getValue("assento"));

    if (form.getValue("nomePassageiro") == "" ){
        msg += i18n.translate("infNomePassageiro");
    }
    if (form.getValue("cpf") == "" ) {
        msg += i18n.translate("infCpf");
    }
    if (form.getValue("idVoo") == ""){
        msg += i18n.translate("infIdVoo");
    }
    if (form.getValue("assento") == "") {
        msg += i18n.translate("infAssento");
    }
    if (form.getValue("tipoCliente") == "") {
        msg += i18n.translate("infTipoCliente");
    }

    if (msg != "") {
        throw msg;
    }

    var filtroAssento = DatasetFactory.createConstraint("idVoo", idVoo, idVoo, ConstraintType.MUST);
    var voo = DatasetFactory.getDataset("dsCadastrodeVoos", null, new Array(filtroAssento), null);

    if (voo.rowsCount == 0) {
        throw i18n.translate("vooNao");
    }

    var limite = parseInt(voo.getValue(0, "quantAssentos"));

    if (assento > limite || assento <= 0) {
        throw i18n.translate("assentoInvalido") + limite;
    }

    var todos = DatasetFactory.getDataset("dsEmissaodePassagens", null, null, null);

    for (var i = 0; i < todos.rowsCount; i++) {
        if (todos.getValue(i, "idVoo") == idVoo && todos.getValue(i, "assento") == String(assento)) {
            throw i18n.translate("assentoOcupado1") + assento + " " + i18n.translate("assentoOcupado2");
        }
    }
}



