function validateForm(form) {
	var msg = "";

	var idVoo = form.getValue("idVoo");
	var cpf = form.getValue("cpf");

	if (form.getValue("idVoo") == "") {
		msg += i18n.translate("selecVoo");
	}

	if (form.getValue("cpf") == "") {
		msg += i18n.translate("infCPF");
	}

	if (idVoo) {
		var filtroVoo = DatasetFactory.createConstraint("idVoo", idVoo, idVoo,
				ConstraintType.MUST);
		var dsVoo = DatasetFactory.getDataset("dsCadastrodeVoos", null,
				new Array(filtroVoo), null);

		if (dsVoo.rowsCount == 0) {
			msg += i18n.translate("vooNao");
		} else {
			var status = dsVoo.getValue(0, "statusVoo");
			if (status == "cancelado") {
				msg += i18n.translate("vooCancelado");
			}
		}
	}
	if (idVoo && cpf) {
		var c1 = DatasetFactory.createConstraint("idVoo", idVoo, idVoo,
				ConstraintType.MUST);
		var c2 = DatasetFactory.createConstraint("cpf", cpf, cpf,
				ConstraintType.MUST);
		var filtroPassagem = new Array(c1, c2);
		var dsPassagem = DatasetFactory.getDataset("dsEmissaodePassagens",
				null, filtroPassagem, null);

		if (dsPassagem.rowsCount == 0) {
			msg += i18n.translate("passNao");
		}
	}

	if (msg != "") {
		throw msg;
	}
}
