function displayFields(form, customHTML) {
    var modo = form.getFormMode();

    if (modo != "VIEW") {
        customHTML.append('<script>$("#mensagemInteracao").hide(); $("#formPrincipal").show();</script>');
    } else {
        
        var idVoo = form.getValue("idVoo");

        var numeroVoo = "";
        var horarioPartida = "";
        var horarioChegada = "";
        var localPartida = "";
        var localChegada = "";
        var tipoVoo = "";
        var assento = "";
        var nomePassageiro = "";
        var tipoCliente = "";
        var cpf = "";
        var statusVoo = "";

        var filtroVoo = DatasetFactory.createConstraint("idVoo", idVoo, idVoo, ConstraintType.MUST);
        var dadosVoo = DatasetFactory.getDataset("dsCadastrodeVoos", null, new Array(filtroVoo), null);

        if (dadosVoo.rowsCount > 0) {
            numeroVoo = dadosVoo.getValue(0, "numeroVoo");
            horarioPartida = dadosVoo.getValue(0, "horarioPartida");
            horarioChegada = dadosVoo.getValue(0, "horarioChegada");
            localPartida = dadosVoo.getValue(0, "localPartida");
            localChegada = dadosVoo.getValue(0, "localChegada");
            tipoVoo = dadosVoo.getValue(0, "tipoVoo");
            statusVoo = dadosVoo.getValue(0, "statusVoo");
        }

        var filtroPassagem = DatasetFactory.createConstraint("idVoo", idVoo, idVoo, ConstraintType.MUST);
        var dadosPassagem = DatasetFactory.getDataset("dsEmissaodePassagens", null, new Array(filtroPassagem), null);

        if (dadosPassagem.rowsCount > 0) {
            assento = dadosPassagem.getValue(0, "assento");
            nomePassageiro = dadosPassagem.getValue(0, "nomePassageiro");
            tipoCliente = dadosPassagem.getValue(0, "tipoCliente");
            cpf = dadosPassagem.getValue(0,"cpf");
        }
        var passagem = '<h1><b>Passagem Válidada</b></h1>' +
        '<h3>Informações do Voo</h3>' +
        '<p><b>Nome do Passageiro:</b> ' + nomePassageiro + '</p>' +
        '<p><b>CPF:</b> ' + cpf + '</p>' +
        '<p><b>Número do Voo:</b> ' + numeroVoo + '</p>' +
        '<p><b>Partida:</b> ' + horarioPartida + '</p>' +
        '<p><b>Chegada:</b> ' + horarioChegada + '</p>' +
        '<p><b>Assento:</b> ' + assento + '</p>' +
        '<p><b>Status do Voo:</b> ' + statusVoo + '</p>' +
        '<p><b>Local de Partida:</b> ' + localPartida + '</p>' +
        '<p><b>Local de Chegada:</b> ' + localChegada + '</p>' +
        '<p><b>Tipo do Voo:</b> ' + tipoVoo + '</p>' +
        '<p><b>Cliente:</b> ' + tipoCliente + '</p>';
        
        customHTML.append('<script>$("#mensagemInteracao").append("'+passagem+'");</script>');
        customHTML.append('<script>$("#mensagemInteracao").show(); $("#formPrincipal").hide();</script>');
    }
}
