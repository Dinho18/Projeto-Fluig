function displayFields(form, customHTML) {
	
    var modo = form.getFormMode();

    if (modo != "VIEW") {

        customHTML.append('<script>$("#mensagemInteracao").hide(); $("#formPrincipal").show();</script>');
    }

    else {
        var nomePassageiro = form.getValue("nomePassageiro");
        var cpf = form.getValue("cpf");
        var idVoo = 0;
        	idVoo = form.getValue("idVoo");
        var assento = form.getValue("assento");
        var tipoCliente = form.getValue("tipoCliente");

        
        var numeroVoo = "";
        var horarioPartida = "";
        var horarioChegada = "";
        var portaoEmbarque = "";
        var statusVoo = "";
        var localPartida = "";
        var localChegada = "";
        var tipoVoo = "";

       
        var filtroVoo = DatasetFactory.createConstraint("idVoo", idVoo, idVoo, ConstraintType.MUST);
        var dadosVoo = DatasetFactory.getDataset("dsCadastrodeVoos", null, new Array(filtroVoo), null);
        
        if ( dadosVoo.rowsCount > 0) {
            numeroVoo = dadosVoo.getValue(0, "numeroVoo");
            horarioPartida = dadosVoo.getValue(0, "horarioPartida");
            horarioChegada = dadosVoo.getValue(0, "horarioChegada");
            portaoEmbarque = dadosVoo.getValue(0, "portaoEmbarque");
            statusVoo = dadosVoo.getValue(0, "statusVoo");
            localPartida = dadosVoo.getValue(0, "localPartida");
            localChegada = dadosVoo.getValue(0, "localChegada");
            tipoVoo = dadosVoo.getValue(0, "tipoDeVoo");
        }	
        
        var passagem = '<h1><b>Passagem</b></h1>' +
        '<h3>Informações do Voo</h3>' +
        '<p><b>Nome do Passageiro:</b> ' + nomePassageiro + '</p>' +
        '<p><b>CPF:</b> ' + cpf + '</p>' +
        '<p><b>Número do Voo:</b> ' + numeroVoo + '</p>' +
        '<p><b>Partida:</b> ' + horarioPartida + '</p>' +
        '<p><b>Chegada:</b> ' + horarioChegada + '</p>' +
        '<p><b>Assento:</b> ' + assento + '</p>' +
        '<p><b>Status do Voo:</b> ' + statusVoo + '</p>' +
        '<p><b>Local de Partida:</b> ' + localPartida + '</p>' +
        '<p><b>Local de Chegada:</b> ' + localChegada + '</p>' +
        '<p><b>Tipo do Voo:</b> ' + tipoVoo + '</p>' +
        '<p><b>idVoo:</b> ' + idVoo + '</p>' +
        '<p><b>Cliente:</b> ' + tipoCliente + '</p>';
        
        customHTML.append('<script>$("#mensagemInteracao").append("'+passagem+'");</script>');
        customHTML.append('<script>$("#mensagemInteracao").show(); $("#formPrincipal").hide();</script>');
    }
}
