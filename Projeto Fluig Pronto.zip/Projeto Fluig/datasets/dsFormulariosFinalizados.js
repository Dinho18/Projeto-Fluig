function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
	var dataset = DatasetBuilder.newDataset(); 

    dataset.addColumn("cardDocumentId");
    dataset.addColumn("status");

    var c1 = DatasetFactory.createConstraint("status", "2", "2", ConstraintType.MUST);
    var c2 = DatasetFactory.createConstraint("processId", "Cadastro de Voos D", "Cadastro de Voos D", ConstraintType.MUST);
    var c3 = new Array(c1,c2);
    
    var workflowData = DatasetFactory.getDataset("workflowProcess", null, c3, null);

    if (workflowData != null && workflowData.rowsCount > 0) {
     
        for (var i = 0; i < workflowData.rowsCount; i++) {
            var cardDocumentId = workflowData.getValue(i, "cardDocumentId");
            var status = workflowData.getValue(i, "status");
            
            dataset.addRow([cardDocumentId, status]);
        }
    }

    return dataset; 
}

function onMobileSync(user) {

}